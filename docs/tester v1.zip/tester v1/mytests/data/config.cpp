#include <ArduinoJson.h>
#include <datatable.h>

struct Config :public Item 
{
	//char wifi_ssid[32] = "AndroidAP";
	//char wifi_pass[64] = "gzfq4137";
	char wifi_ssid[32] = "Movistar_1664";
	char wifi_pass[64] = "EGYDRNA6H4Q";
	char www_user[32] = "admin";
	char www_pass[64] = "admin";
	float screw_pitch = 2.0;
	uint8_t micro_step= 8; // 1 / 8
	uint8_t speed= 8;// mm/s
	uint8_t acc_desc= 4;// mm/s²


	//private print result;
	String r;
	
	void serializeItem(JsonObject &obj, bool extra) {
		if (!extra) {
			obj["wifi_pass"] = this->wifi_pass;
			obj["www_pass"] = this->www_pass;
			obj["www_user"] = this->www_user;
		}
		obj["wifi_ssid"] = this->wifi_ssid;

		obj["acc_desc"] = this->acc_desc;
		obj["speed"] = this->speed;

		obj["screw_pitch"] = this->screw_pitch;
		obj["micro_step"] = this->micro_step;
	};
	
	void deserializeItem(JsonObject &obj) {
		if (!obj["wifi_ssid"].is<const char*>() || !obj["wifi_pass"].is<const char*>() || 
			!obj["www_user"].is<const char*>() || !obj["www_pass"].is<const char*>()|| 
			!obj["micro_step"].is<uint8_t>() || !obj["speed"].is<uint8_t>()||
			!obj["screw_pitch"].is<float>() || !obj["acc_desc"].is<uint8_t>())
		{
			Serial.println("faill deserializeItem Config");
			return;
		}

		
		strcpy(this->www_user, obj["www_user"].as<const char*>());
		strcpy(this->www_pass, obj["www_pass"].as<const char*>());
		
		strcpy(this->wifi_ssid, obj["wifi_ssid"].as<const char*>());
		strcpy(this->wifi_pass, obj["wifi_pass"].as<const char*>());
		
		this->screw_pitch = obj["screw_pitch"].as<float>();
		this->micro_step = obj["micro_step"].as<uint8_t>();
		
		this->acc_desc = obj["acc_desc"].as<uint8_t>();
		this->speed = obj["speed"].as<uint8_t>();

	};
};


Config config;

void setup() {
  // Initialize serial port
  Serial.begin(115200);
  delay(1000);

  
	JsonDocument doc;
	JsonObject obj = doc.to<JsonObject>();
	String str;

	config.serializeItem(obj,false);
	serializeJsonPretty(obj, str);
	Serial.println(str.c_str());


	JsonDocument doc1;
JsonObject login = doc1["login"].to<JsonObject>();
login["name"] = "admin";
login["pass"] = "admin";

Serial.println(doc1["login"].is<JsonObject>());
Serial.println(doc1["login"]["name"].is<const char*>());

}

void loop() {
  // not used in this example
}
