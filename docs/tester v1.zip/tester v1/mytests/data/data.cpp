#include <ArduinoJson.h>
#include <datatable.h>

struct Config :public Item 
{
	//char wifi_ssid[32] = "AndroidAP";
	//char wifi_pass[64] = "gzfq4137";
	char wifi_ssid[32] = "Movistar_1664";
	char wifi_pass[64] = "EGYDRNA6H4Q";
	char www_user[32] = "admin";
	char www_pass[64] = "admin";

	//private print result;
	String r;

	void set(
		const char * wifi_ssid, const char * wifi_pass,
		const char *www_user, const char *www_pass) 
	{
		setWifi(wifi_ssid, wifi_pass);
		setAdmin(www_user, www_pass);
	};
	
	bool setAdmin(const char * www_user, const char * www_pass) 
	{
		if (strlen(www_user) > 32 || strlen(www_pass) > 64) 
			return false;

		strcpy(this->www_user, www_user);
		strcpy(this->www_pass, www_pass);
		return true;
	};
	bool setWifi(const char * wifi_ssid, const char * wifi_pass) 
	{
		if (strlen(wifi_ssid) > 32 || strlen(wifi_pass) > 64)
			return false;

		strcpy(this->wifi_ssid, wifi_ssid);
		strcpy(this->wifi_pass, wifi_pass);
		return true;
	};

	void serializeItem(JsonObject &obj, bool extra) {
		if (!extra) {
			obj["wifi_pass"] = this->wifi_pass;
			obj["www_pass"] = this->www_pass;
			obj["www_user"] = this->www_user;
		}
		obj["wifi_ssid"] = this->wifi_ssid;
	};

	bool deserializeItem(JsonObject &obj) {
		if (!obj["wifi_ssid"].is<const char*>() || !obj["wifi_pass"].is<const char*>() || 
			!obj["www_user"].is<const char*>() || !obj["www_pass"].is<const char*>())
		{
			Serial.println("faill deserializeItem Config");
			return false;
		}

		set(
			obj["wifi_ssid"].as<const char*>(), obj["wifi_pass"].as<const char*>(),
			obj["www_user"].as<const char*>(), obj["www_pass"].as<const char*>()
		);
		return true;
	};
};


struct MyItem : public Item
{
	uint8_t edad;
	char name[20] = "";

	void set(int id, uint8_t edad, const char * name)
	{
		this->id = id; this->edad = edad;
		strcpy(this->name, name);
	};
	void serializeItem(JsonObject &obj, bool extra) 
	{
		obj["id"] = this->id;
		obj["edad"] = this->edad;
		obj["name"] = this->name;
	};
	bool deserializeItem(JsonObject &obj) {

		set(
			obj["id"].as<int>(),
			obj["edad"].as<int>(),
			obj["name"].as<const char*>()
		);
		return true;
	};
};

DataTable<7,MyItem> myTable;
DataList<5,MyItem> myList;

void setup() {
  // Initialize serial port
  Serial.begin(115200);
  delay(1000);

  Serial.println(myTable.maxSize);

	//fill table
	int i = myTable.size();
	while (myTable.size() < myTable.maxSize)
	{
		String t = "table " + (String)++i;

		MyItem* item = myTable.getEmpty();
		if (item) {
			item->set(Item::CREATE_NEW, 69 - i, t.c_str());
			Serial.println((myTable.push(item)  == nullptr));
		}
	}

  Serial.println("myTable");
	for (auto pair : myTable)
		Serial.printf("\tid %d %s \n", pair.first, pair.second->name);

	
	Serial.println(myTable.serializeString());

  // Allocate the JSON document
  JsonDocument doc;

  // JSON input string.
  const char* json = "{\"sensor\":\"gps\",\"time\":1351824120,\"data\":[48.756080,2.302038]}";

  // Deserialize the JSON document
  DeserializationError error = deserializeJson(doc, json);

  // Test if parsing succeeds.
  if (error) {
    Serial.print(F("deserializeJson() failed: "));
    Serial.println(error.f_str());
    return;
  }

  // Fetch values.
  //
  // Most of the time, you can rely on the implicit casts.
  // In other case, you can do doc["time"].as<long>();
  const char* sensor = doc["sensor"];
  long time = doc["time"];
  double latitude = doc["data"][0];
  double longitude = doc["data"][1];

  // Print values.
  Serial.println(sensor);
  Serial.println(time);
  Serial.println(latitude, 6);
  Serial.println(longitude, 6);
}

void loop() {
  // not used in this example
}
