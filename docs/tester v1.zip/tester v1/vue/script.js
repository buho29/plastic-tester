
var host = document.location.host;
// para ejecutar el html fuera del esp32 
var host = '192.168.1.57';

// mixin para insertar notificaciones
const mixinNotify = {
  methods:{
    notify: function (msg) {
      //quasar notify
      this.$q.notify({
          color: 'primary', textColor: 'white',
          icon: 'icon-cloud_done',
          message: msg
      });
    },
    notifyW: function (msg) {
      this.$q.notify({
          color: 'accent', textColor: 'dark',
          icon: 'icon-warning',
          message: msg
      })
    },
  }
};

//vue components
Vue.component("b-sensor", {
  props: ["prop", "value"],
  template: /*html*/ `
  <q-card class="text-subtitle1 q-ma-lg">
    <q-card-section class="q-pa-none text-primary" style="min-width:100px;">
      <div class="q-pa-sm">{{ prop }}</div>
      <q-separator />
    </q-card-section>
    <q-card-section>
      <div class="text-dark">{{ value }}</div>
    </q-card-section>
  </q-card>
`,
});

Vue.component("chart", {
  props: ["prop", "data"], //width: 800px;
  template: /*html*/ `
    <q-card  class="q-ma-md">
      <q-card-section class="q-pa-none q-ma-none">
        <div class="bg-primary text-white shadow-3 ">
          <div  class="text-h6 q-pa-sm">{{prop}}</div>
        </div>
      </q-card-section>
      <q-card-section>
          <vue-chart class="" style="height: 300px;" :data="data"
            :options="{responsive: true,maintainAspectRatio: false,scales: {yAxes: [{ticks: {beginAtZero: false}}]}}"
            :update-config="{duration: 500, easing: 'easeInCubic'}" type="line"/>
      </q-card-section>
    </q-card>
      `,
});

//Paginas
const pageHome = {
  computed: {
    ...Vuex.mapState(["sensors"]),
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="flex justify-center q-ma-none q-pa-none bg-grey-1">
      <b-sensor prop="Position" :value="sensors.d+'mm'"/>
      <b-sensor prop="Force" :value="sensors.f+'kg'"/>
    </div>
    <q-separator />
    <div class="q-pa-lg">
    
    <q-btn push label="Run Test" size="xl" class="q-ma-md bthome" color="primary"
        glossy stack icon="icon-directions_run" to="test"/>
    
    <q-btn push label="Move" size="xl" class="q-ma-md bthome" color="positive"
        glossy stack icon="icon-control_camera" to="move"/>
    
    
    <q-btn push label="Historial" size="xl"  class="q-ma-md bthome" color="accent"
        glossy stack icon="icon-trending_up" to="charts"/>
    
    
    <q-btn push label="Opciones" size="xl" class="q-ma-md bthome" color="info"
        glossy stack icon="icon-settings" to="options"/>
    
    </div >
  </q-card>
</q-page>
`,
};

const pageLogin = {
  data: function () {
    return {
      name: null,
      pass: null,
      isPwd: true,
    };
  },
  methods: {
    ...Vuex.mapActions(['setAuthentication']),
    onSubmit() {
        this.setAuthentication({ name: this.name, pass: this.pass });
    },
    onReset() {
        this.name = null;
        this.pass = null;
    }
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="q-pa-lg">

    <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-sm" >
      
              <q-input filled v-model="name" label="Name" dense
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']">
              </q-input>
                  
              <q-input v-model="pass" filled dense label="Password"
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']"
                :type="isPwd ? 'password' : 'text'">
                
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'icon-visibility_off' : 'icon-remove_red_eye'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
                  
              <div>
                  <q-btn label="Enviar" type="submit" color="primary"/>
                  
                  <q-btn label="Reset" type="reset" color="primary" flat/>
              </div>
            </q-form>
    
    </div >
  </q-card>
</q-page>
`,
};

const pageTest = {
  computed: {
    ...Vuex.mapState(["sensors"]),
  },
  methods:{
    ...Vuex.mapActions(["sendCmd"]),
    onStop() {
      this.sendCmd({stop:1});
    },
    onRun(step) {
      this.sendCmd({run:step});
    },
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="flex justify-center q-ma-none q-pa-none bg-grey-1">
      <b-sensor prop="Position" :value="sensors.d+'mm'"/>
      <b-sensor prop="Force" :value="sensors.f+'kg'"/>
    </div>
    <q-separator />
    <q-card-section class="q-pa-lg">
      <q-btn-group class="q-ma-lg">
        <q-btn glossy label="Run" @click="onRun(1)" />
        <q-btn glossy label="Reset" @click="onRun(0)"/>
      </q-btn-group>
      <q-btn push label="STOP" size="xl" color="red" 
        @click="onStop" glossy stack icon="icon-error" />
    </q-card-section>
  </q-card>
</q-page>
`,
};

const pageMove = {
  data: function () {
    return {
      dist_id: '3',
      dists: [0.5,2,10,50]
    };
  },
  computed: {
    ...Vuex.mapState(["sensors"]),
  },
  methods:{
    ...Vuex.mapActions(["sendCmd"]),
    onStop() {
      this.sendCmd({stop:1});
    },
    onMove(dir) {
      this.sendCmd({move:{
        dir: dir,
        dist: this.dists[this.dist_id],
      }});
    },
    onHome() {
      this.sendCmd({sethome:1});
    },
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="flex justify-center q-ma-none q-pa-none bg-grey-1">
      <b-sensor prop="Position" :value="sensors.d+'mm'"/>
      <b-sensor prop="Force" :value="sensors.f+'kg'"/>
    </div>
    <q-separator />
    <q-card-section >
      <q-btn-toggle v-model="dist_id" push toggle-color="primary"
        :options="[
          {label: '0.5mm', value: '0'},
          {label: '2mm', value: '1'},
          {label: '10mm', value: '2'},
          {label: '50mm', value: '3'},
        ]"
      />
      <div class="q-pa-lg">
      <q-btn-group class="q-ma-lg">
        <q-btn glossy icon="icon-fast_rewind" 
          @click="onMove(-1)"/>
        <q-btn glossy icon="icon-fast_forward"  
          @click="onMove(1)"/>
        <q-btn glossy @click="onHome">
          Set<br>Home
        </q-btn>
      </q-btn-group>
      <q-btn push label="STOP" size="xl" color="red" 
        @click="onStop" glossy stack icon="icon-error "/>
      </div>
    </q-card-section>
  </q-card>
</q-page>
`,
};

const pageCharts = {
  computed: {
    ...Vuex.mapState(["chartsData"]),
  },
  components: { "vue-chart": VueChart },
  props: ["data"],
  template: /*html*/ `
    <q-page>
      <div class="col text-center">
        <chart  v-for ="(charti,name) in chartsData" :key="name" :prop="name" :data="chartsData[name]"></chart>
      </div>
    </q-page>
      `,
};

const pageOptions = {
  data: function () {
    return {
      isPwd: true,
      tab: "speed",
      options: {
        speed:null, acc_desc:null,
        screw_pitch:null, micro_step:null,
        wifi_ssid:null,wifi_pass:null,
        www_pass:null,www_user:null,
      },
    };
  },
  computed: {
    ...Vuex.mapState(["authenticate","isConnected","config"]),
  },
  methods: {
    ...Vuex.mapActions(['loadJson','editConfig']),
    onSubmit() {
      switch (this.tab) {
        case "speed":
          this.editConfig({ speed: this.options.speed, 
            acc_desc: this.options.acc_desc});
          break;
        case "motor":
          this.editConfig({ screw_pitch: this.options.screw_pitch, 
            micro_step: this.options.micro_step});
          break;
        case "wifi":
          this.editConfig({ wifi_ssid: this.options.wifi_ssid, 
            wifi_pass: this.options.wifi_pass});
          break;
        case "user":
          this.editConfig({ www_user: this.options.www_user, 
            www_pass: this.options.www_pass});
          break;
      }
    },
  }, 
  mounted() {
    if(this.authenticate && this.isConnected)
      //nos registramos a eventos auth al servidor 
      //q nos devolvera los datos
      this.loadJson(0);
  },
  beforeDestroy() {
    //this.loadJson(-1);
  },
  watch: {
    //si abren directamente la pagina
    isConnected: function (newValue, oldValue) {
      //para cargar datos
      if(this.authenticate && newValue)
        this.loadJson(0);
    },
    //si actualiza config
    config: function (newValue, oldValue) {
      //actualizamos los datos cargados
      for (const key in newValue) {
        this.options[key] = newValue[key];
      }
    }
  },
  template: /*html*/ `
  <q-page>

    <div class="q-mx-auto text-center items-center page bg-white">
      
      <div class="q-pa-md" >
        
        <q-tabs
          v-model="tab"
            class="bg-primary text-white shadow-1"
            indicator-color="accent" align="justify"
        >
          <q-tab name="speed" label="Speed"/>
          <q-tab name="motor" label="Motor" />
          <q-tab name="wifi" label="Wifi" />
          <q-tab name="user" label="User" />
        </q-tabs>


        <q-tab-panels v-model="tab" animated>

          <q-tab-panel name="speed">
              <q-form @submit="onSubmit" class="q-gutter-md " >
                                                                                                                                                                                                                                                            
                <q-input step="any" filled type="number" v-model.number="options.speed" label="Speed" hint="mm/sc"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                  
                />

                <q-input step="any" filled type="number" v-model.number="options.acc_desc" label="Acc/Desc" hint="mm/sc²"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                />
                                                                                                                                                                                                                                           
                <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
                </div>

             </q-form>
          </q-tab-panel>

          <q-tab-panel name="motor">
            <q-form @submit="onSubmit" class="q-gutter-md " >
                                                                                                                                                                                                                                                            
                <q-input step="any" filled type="number" 
                  v-model.number="options.screw_pitch" label="Screw pitch" hint="mm"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                  
                />

                <q-input filled type="number" v-model.number="options.micro_step" label="Driver microsteep" hint="1/value"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                />
                                                                                                                                                                                                                                           
                <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
                </div>

             </q-form>
          </q-tab-panel>

          <q-tab-panel name="wifi">
            <q-form @submit="onSubmit" class="q-gutter-sm" >
      
              <q-input filled v-model="options.wifi_ssid" label="SSID(wifi)" dense
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']">
              </q-input>
              <q-input v-model="options.wifi_pass" filled dense label="Password"
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']"
                :type="isPwd ? 'password' : 'text'">
                
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'icon-visibility_off' : 'icon-remove_red_eye'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
                  
              <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
              </div>
            </q-form>
          </q-tab-panel>   
          <q-tab-panel name="user">
            <q-form @submit="onSubmit" class="q-gutter-sm" >
      
              <q-input filled v-model="options.www_user" label="Name" dense
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']">
              </q-input>
              <q-input v-model="options.www_pass" filled dense label="Password"
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']"
                :type="isPwd ? 'password' : 'text'">
                
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'icon-visibility_off' : 'icon-remove_red_eye'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
                  
              <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
              </div>
            </q-form>
          </q-tab-panel>            
        </q-tab-panels>

      </div>

    </div>
  </q-page>
  `,
};

const pageSystem = {
  data: function () {
    return {
      tab: "system",
    };
  },
  computed: {
    ...Vuex.mapState(["authenticate","isConnected","system"]),
  },
  methods: {
    ...Vuex.mapActions(['loadJson','restart']),
  }, 
  mounted() {
    if(this.authenticate && this.isConnected)
      //nos registramos a eventos auth al servidor 
      //q nos devolvera los datos
      this.loadJson(1);
  },
  beforeDestroy() {
    //this.loadJson(-1);
  },
  watch: {
    //si abren directamente la pagina
    isConnected: function (newValue, oldValue) {
      //nos registramos a eventos auth al servidor
      //para cargar datos
      if(this.authenticate && newValue)
        this.loadJson(1);
    }
  },
  template: /*html*/ `
 <q-page>

    <div class="q-mx-auto text-center items-center page bg-white">
      
      <div class="q-pa-md" >
        
        <q-tabs v-model="tab"
            class="bg-primary text-white shadow-1"
            indicator-color="accent" align="justify"
        >
          <q-tab name="system" label="system"/>
          <q-tab name="icons" label="icons fonts" />
        </q-tabs>


        <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="system">
            <div class="q-pa-md" >
              <div  v-for="(value,key) in system" class="row q-mx-auto " style="width:60%;" >
                <div class="col text-bold text-capitalize text-left"> {{key}}</div>
                <div class="col text-right"> {{value}}</div>
              </div>
              <q-btn color="primary" class="q-ma-sm"
                label="Reset Esp32" @click="restart" />
            </div>
          </q-tab-panel>
          <q-tab-panel name="icons">
            <div class="q-pa-md row items-start">
              <div v-for="(value, key) in icomoon" style="width: 70px;">
                <q-icon :name="key" style="font-size: 2em;"/>
                <p>{{key}}</p>    
              </div>
            </div>            
          </q-tab-panel>
        </q-tab-panels>
  </q-page>
  `,
};

const pageChartID = {
  data: function () {
    return {
      Id: null,
    };
  },
  computed: {
    ...Vuex.mapState(["chartsData"]),
  },
  mounted() {
    this.Id = this.$route.params.id;
    if (this.Id == "") {
      this.router.go(-1);
    }
  },
  template: /*html*/ `
  <q-page class="q-pa-none">
      <div class="col text-center">
        <chart :prop="Id" :data="chartsData[Id]"/>
      </div>
  </q-page>
  `,
};

//router
// cuando requiresAuth=true requiere autentificacion
const pagesRoute = [
  {
    name: "home", path: "/",
    component: pageHome,
    meta: { title: "Tester",requiresAuth:false},
  },
  {
    name: "charts", path: "/charts",
    component: pageCharts,
    meta: { title: "Historial",requiresAuth:false},
  },
  {
    name: "test", path: "/test",
    component: pageTest,
    meta: { title: "Run Test",requiresAuth:true},
  },
  {
    name: "move", path: "/move",
    component: pageMove,
    meta: { title: "Move",requiresAuth:true},
  },
  {
    name: "chart", path: "/chart/:id",
    component: pageChartID,
    meta: { title: "Result",requiresAuth:true},
  },
  {
    name: "login", path: "/login",
    component: pageLogin,
    meta: { title: "Login",requiresAuth:false},
  },
  {
    name: "options", path: "/options",
    component: pageOptions,
    meta: { title: "Options",requiresAuth:true},
  },
  {
    name: "system", path: "/system",
    component: pageSystem,
    meta: { title: "System",requiresAuth:true},
  },
];

//menu leftdata
const menu = [
  { title: "Home", icon: "icon-home", path: "/" },
  { title: "Run Test", icon: "icon-directions_run", path: "/test" },
  { title: "Move", icon: "icon-control_camera", path: "/move" },
  { title: "Historial", icon: "icon-trending_up", path: "/charts" },
  { title: "Opciones", icon: "icon-settings", path: "/options" },
  { title: "System", icon: "icon-build", path: "/system" },
];

Vue.use(VueRouter);

const router = new VueRouter({ routes: pagesRoute });

//model
Vue.use(Vuex);
const store = new Vuex.Store({
  state: {
    sensors: {
      d: Math.round(Math.random() * (1 - 15) + 15),
      f: Math.round(Math.random() * (100 - 30) + 30),
    },
    chartsData: {
      Pla: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        datasets: [
          {
            label: "Value",
            data: [24, 32, 28, 18, 20, 24, 28, 27, 18, 20],
            borderColor: "#ffbb33", borderWidth: 3,
          },
        ],
      },
      Abs: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        datasets: [
          {
            label: "Value",
            data: [40, 60, 50, 55, 60, 80, 65, 40, 48, 80],
            borderColor: "#ffbb33", borderWidth: 3,
          },
        ],
      },
      Petg: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        datasets: [
          {
            label: "Value",
            data: [908, 1015, 955, 850, 950, 999, 867, 1050, 1000],
            borderColor: "#ffbb33", borderWidth: 3,
          },
        ],
      },
    },
    config: {},
    system: {},
    isConnected: false,
    authenticate:false,
    loaded:false,
  },
  mutations: {// update state

    updateSensors(state, obj) { 
      state.sensors = obj; 
    },
    updateConfig(state, obj) { 
      state.config = obj;
    },
    updateSystem(state, obj) { 
      state.system = obj;
    },
    
    //login
    authenticated(state,token){
      state.authenticate = true;
      state.token = token;
      localStorage.setItem('token',token);
    },
    //logout
    logout(state){
      state.authenticate = false;
      state.token = undefined;
      localStorage.removeItem('token');
    },
    //carga local
    loadLocal(state){
      let token = localStorage.getItem('token');
      if (token) {
        state.authenticate = true;
        state.token = token;        
      }
    },
    //se cierra la ventana
    unload(state){
      if (this.connection !== undefined) {
        this.connection.close();
      }
    },
    //conected
    connected(state, bool) { 
      state.isConnected = bool; 
    },/**/

  },
  actions: {
    // connexion inicial websocket
    connect({ commit, dispatch }) {
      if (this.connection !== undefined) {
        this.connection.close();
      }

      console.log(host);

      this.connection = new WebSocket('ws://' + host + '/ws');

      //delegamos los eventos a las acciones
      this.connection.onmessage = event => dispatch("onMessage", event);
      this.connection.onclose = event => dispatch("onClose", event);
      this.connection.onerror = event => dispatch("onError", event);
      this.connection.onopen = event => dispatch("onOpen", event);

    },
    //reiniciar esp32
    restart({dispatch }) {
      dispatch("send", {
        cmd: { restar: 1}
      });
    },
    // intento de autentificacion
    setAuthentication({dispatch, commit, state }, user) {
      if (this.connection !== undefined) {
        this.connection.send(
          JSON.stringify({ login: user})
        );
      } else dispatch("connect");
    },
    // recibe wasaps del servidor de eventos/errores
    // hay q suscribirse a vuex para tratar los mensajes
    notify({ commit, state }, notify) {
      //is event
    },
    // para manejar el routing desde servidor y vuex
    // podemos abrir paginas al usuario
    // hay q suscribirse a vuex
    goTo({ commit, state }, path) {
      //is event
    },
    // para cerrar la session del usuario desde el servidor
    logoutUser({ dispatch,commit, state }, path) {
      commit("logout");
      dispatch("goTo","/login");
    },

    //para descargar datos autenticadas
    loadJson({dispatch},id){
      dispatch("send", { loadAuth:id });
    },

    editConfig({ commit, dispatch }, obj) {
      dispatch("send", { config: obj});
    },
    
    sendCmd({ commit, dispatch }, obj) {
      dispatch("send", { cmd: obj});
    },
    
    //envia objectos/comandos en json al servidor
    send({ commit, dispatch ,state}, obj) {
      // si no estamos identificado
      if(!state.authenticate){
        dispatch("goTo","/login");
        dispatch("notify",{type:2,content:"login required"});
        return;
      }

      //metemos el token
      obj.token = state.token;
        
      if (this.connection !== undefined) {
        this.connection.send(
          JSON.stringify(obj)
        );
      } else dispatch("connect");
    },
    //privado
    // eventos websocket
    //json recibido del Esp32
    onMessage({ commit, dispatch }, event) {
      //convierte json en un objecto js
      let json = JSON.parse(event.data);
      // TODO mutations
      const mutations ={
        ss:"updateSensors", token:"authenticated", 
        system:'updateSystem', config:'updateConfig',
        history: 'updatehHistory',
      }
      //actualizamos los datos por commit("mutation")
      for (const key in mutations) {
        if(json[key]!==undefined)
          commit(mutations[key], json[key]);
      }

      let actions ={
        message:"notify", goTo:"goTo", logout:"logoutUser"
      }
      //ejecutamos acciones dispatch("action")
      for (const key in actions) {
        if(json[key]!==undefined)
          dispatch(actions[key], json[key]);
      }
      
    },
    onClose({ commit, dispatch }, event) {
      // ponemos state.isConnected a false
      commit("connected", false);
      //reconectamos al pasar 3sg
      setTimeout(() => {
        dispatch("connect");
      }, 3000)
    },
    onError({ commit, state }, event) {
      //is event
    },
    onOpen({ commit, state }, event) {
      commit("connected", true);
    }/**/
  },
  getters: {

  },
  strict: true,
});

//aplication
const app = new Vue({
  el: "#app",
  router,
  store,
  mixins:[mixinNotify],
  data: function () {
    return {
      left: false,
      transitionName: "slide-right",
      pages: menu,
      showMessage: false,
      showLoading:false,
      message:"",
    };
  },
  computed: {
    ...Vuex.mapState(['authenticate','isConnected']),
  },
  methods: {
    // importamos acciones
    ...Vuex.mapActions(['connect',"logoutUser"]),
    ...Vuex.mapMutations(['unload']),
    
    userAuthenticated(){
      return this.authenticate;
    },
  },
  beforeCreate() { 
    //cargamos localStorage (token)
    this.$store.commit('loadLocal');
  },
  mounted() {
    this.$q.iconSet = iconSet;
  },
  beforeDestroy() {
    this.unsubscribe();
  },
  created() {
    
    this.connect();
    // console.log('Updating mutation', action.type,action.payload);
    // nos registrammos a las llamadas de acciones en vuex
    // para interpretar notificaciones y acciones por parte del servidor
    this.unsubscribe = this.$store.subscribeAction((action, state) => {
      
      switch (action.type) {
          // eventos websocket
          case "onClose":
            this.notifyW('disconnected');
            break;
          case "onOpen":
            this.notify('Connected');
            break;
          case "onError":
            this.notifyW('Error');
            break;
          // acciones servidor
          case "notify":
            let pl = action.payload;
            let msg = pl.content;
            //ok
            if(pl.type ===0) this.notify(msg);
            //error
            else if(pl.type ===1){
              this.message = msg;
              this.showMessage = true;
            }// warn
            else if(pl.type == 2){
              this.notifyW(msg);
            }
            break;
          case "goTo":
            let path = action.payload;
            if(this.$route.path !== path){
              this.$router.push(path);
            }
            break;
          case "logout":
            userLogOut();
            break;
        }
      });
  },
  watch: {
    $route(to, from) {
      this.transitionName =
        this.transitionName === "slide-left" ? "slide-right" : "slide-left";
    },
    //mostrando o escondiendo un "loading..."
    isConnected: function (newValue, oldValue) {
      this.showLoading = !newValue;
    },
  },
}).$mount("#app");

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth && !app.userAuthenticated()) {
    next('/login');
  } else {
    next();
  }
});