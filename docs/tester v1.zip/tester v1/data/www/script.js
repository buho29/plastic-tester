const mixinNotify = {
  methods:{
    notify: function (msg) {
        //quasar notify
        this.$q.notify({
            color: 'primary',
            textColor: 'white',
            icon: 'mdi-cloud-check',
            message: msg
        });
    },
    notifyW: function (msg) {
        this.$q.notify({
            color: 'accent',
            textColor: 'dark',
            icon: 'mdi-alert-circle',
            message: msg
        })
    },
  }
};

Vue.component("b-sensor", {
  props: ["prop", "value"],
  template: /*html*/ `
  <q-card class="text-subtitle1 q-ma-lg">
    <q-card-section class="q-pa-none text-primary" style="min-width:100px;">
      <div class="q-pa-sm">{{ prop }}</div>
      <q-separator />
    </q-card-section>
    <q-card-section>
      <div class="text-dark">{{ value }}</div>
    </q-card-section>
  </q-card>
`,
});
//Paginas
const home = {
  computed: {
    ...Vuex.mapState(["sensors"]),
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="q-pa-lg">
    
    <q-btn push label="Run Test" size="xl" class="q-ma-md bthome" color="primary"
        glossy stack icon="mdi-run" to="test"/>
    
    <q-btn push label="Move" size="xl" class="q-ma-md bthome" color="positive"
        glossy stack icon="mdi-cursor-move" to="move"/>
    
    
    <q-btn push label="Historial" size="xl"  class="q-ma-md bthome" color="accent"
        glossy stack icon="mdi-chart-line" to="charts"/>
    
    
    <q-btn push label="Opciones" size="xl" class="q-ma-md bthome" color="info"
        glossy stack icon="mdi-cog" to="options"/>
    
    </div >
  </q-card>
</q-page>
`,
};

//Paginas
const login = {
  data: function () {
    return {
      name: null,
      pass: null,
      isPwd: true,
    };
  },
  computed: {
    //...Vuex.mapState(["sensors"]),
  },
  methods: {
    //...mapActions(['setAuthentication']),
    onSubmit() {
        //this.setAuthentication({ name: this.name, pass: this.pass });
    },
    onReset() {
        this.name = null;
        this.pass = null;
    }
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="q-pa-lg">

    <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-sm" >
      
              <q-input filled v-model="name" label="Name" dense
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']">
              </q-input>
                  
              <q-input v-model="pass" filled dense label="Password"
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']"
                :type="isPwd ? 'password' : 'text'">
                
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'mdi-eye-off' : 'mdi-eye'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
                  
              <div>
                  <q-btn label="Enviar" type="submit" color="primary"/>
                  
                  <q-btn label="Reset" type="reset" color="primary" flat/>
              </div>
            </q-form>
    
    </div >
  </q-card>
</q-page>
`,
};


const test = {
  computed: {
    ...Vuex.mapState(["sensors"]),
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="flex justify-center q-ma-none q-pa-none bg-grey-1">
      <b-sensor prop="Position" :value="sensors.dist+'mm'"/>
      <b-sensor prop="Force" :value="sensors.force+'kg'"/>
    </div>
    <q-separator />
    <q-card-section class="q-pa-lg">
      <q-btn-group class="q-ma-lg">
        <q-btn glossy label="Run" to="chart/Pla"/>
        <q-btn glossy label="Reset" />
      </q-btn-group>
      <q-btn push label="STOP" size="xl" color="red" 
        glossy stack icon="mdi-alert "/>
    </q-card-section>
  </q-card>
</q-page>
`,
};

const movement = {
  data: function () {
    return {
      tab: '3',
    };
  },
  computed: {
    ...Vuex.mapState(["sensors"]),
  },
  template: /*html*/ `
<q-page>
  <q-card class="q-mx-auto text-center bg-white page">
    <div class="flex justify-center q-ma-none q-pa-none bg-grey-1">
      <b-sensor prop="Position" :value="sensors.dist+'mm'"/>
      <b-sensor prop="Force" :value="sensors.force+'kg'"/>
    </div>
    <q-separator />
    <q-card-section >
      <q-btn-toggle
        v-model="tab"
        push toggle-color="primary"
        :options="[
          {label: '0.5mm', value: '0'},
          {label: '2mm', value: '1'},
          {label: '10mm', value: '2'},
          {label: '50mm', value: '3'},
        ]"
      />
      <div class="q-pa-lg">
      <q-btn-group class="q-ma-lg">
        <q-btn glossy label="<<" />
        <q-btn glossy label=">>" />
        <q-btn glossy >
          Set<br>Home
        </q-btn>
      </q-btn-group>
      <q-btn push label="STOP" size="xl" color="red" 
        glossy stack icon="mdi-alert "/>
      </div>
    </q-card-section>
  </q-card>
</q-page>
`,
};

Vue.component("chart", {
  props: ["prop", "data"], //width: 800px;
  template: /*html*/ `
    <q-card  class="q-ma-md">
      <q-card-section class="q-pa-none q-ma-none">
        <div class="bg-primary text-white shadow-3 ">
          <div  class="text-h6 q-pa-sm">{{prop}}</div>
        </div>
      </q-card-section>
      <q-card-section>
          <vue-chart class="" style="height: 300px;" :data="data"
    :options="{responsive: true,maintainAspectRatio: false,scales: {yAxes: [{ticks: {beginAtZero: false}}]}}"
    :update-config="{duration: 500, easing: 'easeInCubic'}" type="line"></vue-chart>
      </q-card-section>
    </q-card>
      `,
});

const charts = {
  computed: {
    ...Vuex.mapState(["chartsData"]),
  },
  components: { "vue-chart": VueChart },
  props: ["data"],
  template: /*html*/ `
    <q-page>
      <div class="col text-center">
        <chart  v-for ="(charti,name) in chartsData" :key="name" :prop="name" :data="chartsData[name]"></chart>
      </div>
    </q-page>
      `,
};

const opciones = {

  data: function () {
    return {
      name: null,
      age: null,
      isPwd: true,
      accept: true,
      tab: "speed",
    };
  },
  methods: {
    onSubmit() {
      if (this.accept == true) {
        this.$q.notify({
          color: "primary",
          textColor: "white",
          icon: "mdi-cloud-check",
          message: "Saved!!",
        });
      }
    },
    onReset() {
      this.name = null;
      this.age = null;
      this.accept = false;
    },
  },
  template: /*html*/ `
  <q-page>

    <div class="q-mx-auto text-center items-center page bg-white">
      
      <div class="q-pa-md" >
        
        <q-tabs
          v-model="tab"
            class="bg-primary text-white shadow-1"
            indicator-color="accent" align="justify"
        >
          <q-tab name="speed" label="Speed"/>
          <q-tab name="motor" label="Motor" />
          <q-tab name="wifi" label="Wifi" />
        </q-tabs>


        <q-tab-panels v-model="tab" animated>

          <q-tab-panel name="speed">
              <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md " >
                                                                                                                                                                                                                                                            
                <q-input filled type="number" v-model="name" label="Speed" hint="mm/sc"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                  
                />

                <q-input filled type="number" v-model="age" label="Acc/Desc" hint="mm/sc²"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                />
                                                                                                                                                                                                                                           
                <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
                </div>

             </q-form>
          </q-tab-panel>

          <q-tab-panel name="motor">
            <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md " >
                                                                                                                                                                                                                                                            
                <q-input step="any" filled type="number" v-model="name" label="Screw pitch" hint="mm"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                  
                />

                <q-input filled type="number" v-model="age" label="Driver microsteep" hint="1/value"
                  lazy-rules :rules="[
                    val => val !== null && val !== '' || 'Please type something',
                    val => val > 1 && val < 100 || 'wrong value'
                  ]"
                />
                                                                                                                                                                                                                                           
                <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
                </div>

             </q-form>
          </q-tab-panel>

          <q-tab-panel name="wifi">
            <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-sm" >
      
              <q-input filled v-model="name" label="SSID(wifi)" dense
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']">
              </q-input>
                  
              <q-input v-model="age" filled dense label="Password"
                lazy-rules :rules="[ val => val && val.length > 0 || 'Please type something']"
                :type="isPwd ? 'password' : 'text'">
                
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'mdi-eye-off' : 'mdi-eye'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
                  
              <div>
                  <q-btn label="Guardar" type="submit" color="primary"/>
              </div>
            </q-form>
          </q-tab-panel>
        </q-tab-panels>
      </div>

    </div>
  </q-page>`,
};

const chartID = {
  data: function () {
    return {
      Id: null,
    };
  },
  computed: {
    ...Vuex.mapState(["chartsData"]),
  },
  mounted() {
    this.Id = this.$route.params.id;
    if (this.Id == "") {
      this.router.go(-1);
    }
  },
  template: /*html*/ `
  <q-page class="q-pa-none">
      <div class="col text-center">
        <chart :prop="Id" :data="chartsData[Id]"/>
      </div>
  </q-page>
      `,
};

//router
const pagesRoute = [
  {
    name: "home",
    path: "/",
    component: home,
    meta: { title: "Tester",requiresAuth:false},
  },
  {
    name: "charts",
    path: "/charts",
    component: charts,
    meta: { title: "Historial",requiresAuth:false},
  },
  {
    name: "test",
    path: "/test",
    component: test,
    meta: { title: "Run Test",requiresAuth:true},
  },
  {
    name: "move",
    path: "/move",
    component: movement,
    meta: { title: "Move",requiresAuth:true},
  },
  {
    name: "chart",
    path: "/chart/:id",
    component: chartID,
    meta: { title: "Result",requiresAuth:true},
  },
  {
    name: "login",
    path: "/login",
    component: login,
    meta: { title: "Login",requiresAuth:false},
  },
  {
    name: "options",
    path: "/options",
    component: opciones,
    meta: { title: "Options",requiresAuth:true},
  },
];

//menu leftdata
const menu = [
  { title: "Home", icon: "mdi-home", path: "/" },
  { title: "Run Test", icon: "mdi-run", path: "/test" },
  { title: "Move", icon: "mdi-cursor-move", path: "/move" },
  { title: "Historial", icon: "mdi-chart-line", path: "/charts" },
  { title: "Opciones", icon: "mdi-cog", path: "/options" },
];

Vue.use(VueRouter);

const router = new VueRouter({ routes: pagesRoute });

//model
Vue.use(Vuex);
const store = new Vuex.Store({
  state: {
    sensors: {
      dist: Math.round(Math.random() * (1 - 15) + 15),
      force: Math.round(Math.random() * (100 - 30) + 30),
    },
    chartsData: {
      Pla: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        datasets: [
          {
            label: "Value",
            data: [24, 32, 28, 18, 20, 24, 28, 27, 18, 20],
            borderColor: "#ffbb33",
            borderWidth: 3,
          },
        ],
      },
      Abs: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        datasets: [
          {
            label: "Value",
            data: [40, 60, 50, 55, 60, 80, 65, 40, 48, 80],
            borderColor: "#ffbb33",
            borderWidth: 3,
          },
        ],
      },
      Petg: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        datasets: [
          {
            label: "Value",
            data: [908, 1015, 955, 850, 950, 999, 867, 1050, 1000],
            borderColor: "#ffbb33",
            borderWidth: 3,
          },
        ],
      },
    },
    config: {},
    system: {},
    isConnected: false,
    loaded:false,
    authenticate:true,


  },
  mutations: {
    deleteChart(state, id) {
      if (id !== "") {
        delete state.chartsData[id];
      }
    },
    
    //login
    authenticated(state,token){
      state.authenticate = true;
      state.token = token;
      localStorage.setItem('token',token);
    },
    //logout
    logout(state){
      state.authenticate = false;
      state.token = undefined;
      localStorage.removeItem('token');
    },
    //carga local
    loadLocal(state){
      let token = localStorage.getItem('token');
      if (token) {
        state.authenticate = true;
        state.token = token;        
      }
    },
    //se cierra la ventana
    unload(state){
      if (this.connection !== undefined) {
        this.connection.close();
      }
    },
    //conected
    connected(state, bool) { 
      state.isConnected = bool; 
    },/**/

  },
  actions: {
    // connexion inicial websocket
    connect({ commit, dispatch }) {
      if (this.connection !== undefined) {
        this.connection.close();
      }

      host = document.location.host;
      if(document.location.host === "")
        host = '192.168.1.57';// para ejecutar el html fuera del esp32 

      console.log(host);

      this.connection = new WebSocket('ws://' + host + '/ws');

      //delegamos los eventos a las acciones
      this.connection.onmessage = event => dispatch("onMessage", event);
      this.connection.onclose = event => dispatch("onClose", event);
      this.connection.onerror = event => dispatch("onError", event);
      this.connection.onopen = event => dispatch("onOpen", event);

    },
    //reiniciar esp32
    restart({dispatch }) {
      dispatch("send", {
        system: { restart: true}
      });
    },
    // intento de autentificacion
    setAuthentication({dispatch, commit, state }, user) {
      if (this.connection !== undefined) {
        this.connection.send(
          JSON.stringify({ login: user})
        );
      } else dispatch("connect");
    },
    // recibe wasaps del servidor de eventos/errores
    // hay q suscribirse a vuex para tratar los mensajes
    message({ commit, state }, message) {
      //is event
    },
    // para manejar el routing desde servidor y vuex
    // podemos abrir paginas al usuario
    // hay q suscribirse a vuex
    goTo({ commit, state }, path) {
      //is event
    },
    //para recibir eventos autenticadas
    registerAuth({dispatch},bool){
      dispatch("send", { auth:bool });
    },

    
    //envia objectos/comandos en json al servidor
    send({ commit, dispatch ,state}, obj) {
      // si no estamos identificado
      if(!state.authenticate){
        //dispatch("goTo","/login");
        dispatch("message",{type:2,content:"2"});
        return;
      }

      //metemos el token
      obj.token = state.token;
        
      if (this.connection !== undefined) {
        this.connection.send(
          JSON.stringify(obj)
        );
      } else dispatch("connect");
    },
    //privado
    // eventos websocket
    //json recibido del servidor
    onMessage({ commit, dispatch }, event) {
      //convierte json en un objecto js
      let json = JSON.parse(event.data);
      // TODO mutations
      const mutations ={
        sensor:"updateSensor",sensors:"updateSensors",
        token:"authenticated", system:'updateSystem',root:'updateRootFiles', 
        config:'updateConfig',history: 'updatehHistory',
      }
      //actualizamos los datos por commit("mutation")
      for (const key in mutations) {
        if(json[key]!==undefined)
          commit(mutations[key], json[key]);
      }

      let actions ={
        message:"message", goTo:"goTo"
      }
      //ejecutamos acciones dispatch("action")
      for (const key in actions) {
        if(json[key]!==undefined)
          dispatch(actions[key], json[key]);
      }
      
    },
    onClose({ commit, dispatch }, event) {
      // ponemos state.isConnected a false
      commit("connected", false);
      //reconectamos al pasar 3sg
      setTimeout(() => {
        dispatch("connect");
      }, 3000)
    },
    onError({ commit, state }, event) {
      //is event
    },
    onOpen({ commit, state }, event) {
      commit("connected", true);
    }/**/
  },
  getters: {

  },
  strict: true,
});

//aplication
const app = new Vue({
  el: "#app",
  router,
  store,
  mixins:[mixinNotify],
  data: function () {
    return {
      left: false,
      transitionName: "slide-right",
      pages: menu,
      showMessage: false,
      showLoading:false,
      message:"",
    };
  },
  computed: {
    ...Vuex.mapState(['authenticate','loaded','isConnected','routingServer']),
  },
  methods: {
    // importamos acciones
    ...Vuex.mapActions(['connect']),
    ...Vuex.mapMutations(['logout','unload']),    
    /*getMsg(pl) {
      if (pl) {
        let args = pl.split("|");
        if(args.length>0){
          return this.$t(`server[${args[0]}]`, [args[1]]);
        }
      }
      return this.$t(`server[${pl}]`);
    },*/
    
    userAuthenticated(){
      return this.authenticate;
    },
    userLogOut(){
      this.logout();
      this.$router.push('/');
    },
  },
  beforeCreate() { 
    //cargamos localStorage (token,lang)
    this.$store.commit('loadLocal');
  },
  mounted() {
    this.$q.iconSet.field.error = "mdi-alert-circle";
    this.$q.iconSet.arrow.dropdown = "mdi-menu-down";
  },
  beforeDestroy() {
    this.unsubscribe();
  },
  created() {
    
    this.connect();
    console.log(this.authenticate);
    // console.log('Updating mutation', action.type,action.payload);
    // nos registrammos a las llamadas de acciones en vuex
    this.unsubscribe = this.$store.subscribeAction((action, state) => {
      
      switch (action.type) {
          case "onClose":
            this.notifyW('app.disconnected');
            break;
          case "onOpen":
            this.notify('app.connected');
            break;
          case "onError":
            this.notifyW('app.error');
            break;
          case "message":
            let pl = action.payload;
            let msg = this.getMsg(pl.content);
            //ok
            if(pl.type ===0) this.notify(msg);
            //error
            else if(pl.type ===1){
              this.message = msg;
              this.showMessage = true;
            }// warn
            else if(pl.type == 2){
              this.notifyW(msg);
            }
            break;
          case "goTo":
            let path = action.payload;
            if(this.$route.path != path && this.routingServer){
              this.$router.push(path);
            }
            break;
        }
      });/*//*/
  },


  watch: {
    $route(to, from) {
      this.transitionName =
        this.transitionName === "slide-left" ? "slide-right" : "slide-left";
    },
  },
}).$mount("#app");

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth && !app.userAuthenticated()) {
    next('/login');
  } else {
    next();
  }
});